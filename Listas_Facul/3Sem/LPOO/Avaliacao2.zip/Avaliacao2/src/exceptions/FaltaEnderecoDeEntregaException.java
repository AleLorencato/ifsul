package exceptions;

public class FaltaEnderecoDeEntregaException extends Exception {
	public FaltaEnderecoDeEntregaException(String msg) {
		super(msg);
	}
}
