package model;

public enum Cidade {
	Pelotas,
	PortoAlegre
}
