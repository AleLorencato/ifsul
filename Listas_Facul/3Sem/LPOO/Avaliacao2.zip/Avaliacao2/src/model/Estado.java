package model;

public enum Estado {
	Aberto,
	Faturado,
	EmTransporte,
	Entregue
}
