package model;

public enum Situacao {
	Ativo,
	Cancelado
}
