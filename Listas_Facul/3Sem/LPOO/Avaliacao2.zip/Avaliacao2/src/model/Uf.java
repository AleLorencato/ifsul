package model;

public enum Uf {
	RS
}
