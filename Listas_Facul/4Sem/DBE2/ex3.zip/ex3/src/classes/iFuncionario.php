<?php
namespace Alexa\Ex3\classes;

interface iFuncionario
{
  function mostrarSalario();

  function mostrarTempoContrato();

}